/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright (c) 2010 Nuvoton Technology Corp. All rights reserved.                                        */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

#include "stdafx.h"
#include "HIDTransferTest.h"
#include "HID.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define USB_VID             0x0416  /* Vendor ID */
#define USB_PID             0x5020  /* Product ID */

#define HID_CMD_SIGNATURE   0x43444948

/* HID Transfer Commands */
#define HID_CMD_TEST        0xB4
#define HID_CMD_ID          0xA5

#define HID_PACKET_SIZE     64

#define USB_TIME_OUT        100

// �Ȧ����@�����ε{������

CWinApp theApp;
CHidCmd io;

using namespace std;

int main(void);

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
    int nRetCode = 0;

    // ��l�� MFC �é󥢱ѮɦC�L���~
    if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
    {
        // TODO: �t�X�z���ݭn�ܧ���~�X
        _tprintf(_T("�Y�����~: MFC ��l�ƥ���\n"));
        nRetCode = 1;
    }
    else
    {
        // TODO: �b�����g���ε{���欰���{���X�C
        main();
    }

    return nRetCode;
}

#pragma pack(push)  /* push current alignment to stack */
#pragma pack(1)     /* set alignment to 1 byte boundary */

typedef struct {
    unsigned char cmd;
    unsigned char len;
    unsigned int arg1;
    unsigned int arg2;
    unsigned int signature;
    unsigned int checksum;
} CMD_T;

#pragma pack(pop)   /* restore original alignment from stack */

unsigned int CalCheckSum(unsigned char *buf, unsigned int size)
{
    unsigned int sum;
    int i;

    i = 0;
    sum = 0;
    while(size--)
    {
        sum += buf[i++];
    }

    return sum;
}

/*
    This function is used to be an simple demo of send command. User may use it as an example to add new command.
*/
int SendTestCmd()
{
    CMD_T cmd;
    bool bRet;
    unsigned long length;

    printf(">>> Test command\n");

    cmd.cmd = HID_CMD_TEST;
    cmd.len = sizeof(cmd) - 4; /* Not include checksum */
    cmd.arg1 = 0x12345678;
    cmd.arg2 = 0xabcdef01;
    cmd.signature = HID_CMD_SIGNATURE;
    cmd.checksum = CalCheckSum((unsigned char *)&cmd, cmd.len);

    bRet = io.WriteFile((unsigned char *)&cmd, sizeof(cmd), &length, USB_TIME_OUT);
    if(!bRet)
    {
        printf("ERROR: Send test command error!\n");
    }

    return 0;
}

/*
    This function is used to enumerate all connected HID USB devices according to the vendor ID/product ID.
    
    usVID     - HID device's vendor ID
    usPID     - HID device's product ID
    deviceIds - The container to store all device IDs
*/
void EnumHidDevice(USHORT usVID, USHORT usPID, vector<unsigned long> &deviceIds)
{
    CMD_T cmd;
    bool isDeviceOpened, bRet;
    unsigned char readBuf[HID_PACKET_SIZE];
    unsigned long deviceId, length;
    int deviceNo;

    isDeviceOpened = 0;
    if(!io.OpenDevice(usVID, usPID))
    {
        printf("Can't Open HID Device\n");
        goto lexit;
    }
    else
    {
        deviceNo = 0;
        while(io.SetDevice(deviceNo))
        {
            printf("USB HID Device VID[%04x] PID[%04x] Open Success.\n", usVID, usPID);
            printf(">>> GetID command\n");

            cmd.cmd = HID_CMD_ID;
            cmd.len = sizeof(cmd) - 4; /* Not include checksum */
            cmd.arg1 = 0x12345678;
            cmd.arg2 = 0xabcdef01;
            cmd.signature = HID_CMD_SIGNATURE;
            cmd.checksum = CalCheckSum((unsigned char *)&cmd, cmd.len);

            bRet = io.WriteFile((unsigned char *)&cmd, sizeof(cmd), &length, USB_TIME_OUT);

            if(!bRet)
            {
                printf("ERROR: Send GetID command error!\n");
                goto lexit;
            }

            memset(readBuf, 0, sizeof(readBuf));
            bRet = io.ReadFile(readBuf, sizeof(readBuf), &length, USB_TIME_OUT);

            if(!bRet)
            {
                printf("ERROR: Read fail!\n");
                goto lexit;
            }

            memcpy(&deviceId, readBuf, sizeof(deviceId));
            printf(">>> Device[%d] ID: 0x%08X\n", deviceNo++, deviceId);
            deviceIds.push_back(deviceId);
        }
    }

lexit:

    return;
}

int main(void)
{
    char choice;
    unsigned long selectedNo;
    vector<unsigned long> deviceIds;
    CHidMutex mutex(0);

    printf("Current Process ID: %u\n", ::GetCurrentProcessId());
    EnumHidDevice(USB_VID, USB_PID, deviceIds);

    while(1)
    {
        while(1)
        {
            printf("Select Device No: ");
            scanf("%u", &selectedNo);

            if(selectedNo < deviceIds.size())
            {
                break;
            }
            else
            {
                printf(">>> Invalid Device No\n");
            }
        }

        choice = 'Y';

        while(1)
        {
            if(toupper(choice) == 'Y')
            {
                mutex.SetID(deviceIds[selectedNo]);

                printf(">>> Open Named Mutex 0x%08X\n", deviceIds[selectedNo]);

                if(mutex.Open() && mutex.Obtain(0))
                {
                    printf(">>> Obtain Mutex Success\n");

                    if(io.SetDevice(selectedNo))
                    {
                        SendTestCmd();
                    }
                    else
                    {
                        printf("Can't Set HID Device\n");
                    }
                }
                else
                {
                    printf(">>> Obtain Mutex Fail\n");
                    mutex.Close();
                    break;
                }
            }

            printf("Release Mutex [Y]? ");
            scanf(" %c", &choice);

            if(toupper(choice) == 'Y')
            {
                mutex.Release();
                break;
            }
        }
    }

    io.CloseDevice();

    return 0;
}